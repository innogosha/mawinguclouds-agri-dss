
// Your Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyDi4kXVNOw7CTcoq9oJeTudpRwV5z6tbWc",
  authDomain: "mawinguclouds-agri-dss.firebaseapp.com",
  projectId: "mawinguclouds-agri-dss",
  storageBucket: "mawinguclouds-agri-dss.appspot.com",
  messagingSenderId: "284741605570",
  appId: "1:284741605570:web:b826d8e5b67f1354e8835b",
  measurementId: "G-15D6YCEXNL"
};
firebase.initializeApp(firebaseConfig);
